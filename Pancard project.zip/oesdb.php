

<?php

/*

*/

require('dbsettings.php');

$conn=false;

function executeQuery($query)
{
    global $conn,$dbserver,$dbname,$dbpassword,$dbusername;
    global $message;
    if (!($conn = pg_connect("host=$dbserver dbname=$dbusername user='postgres'")))
         $message="Cannot connect to server";
    
    $result=pg_query($conn,$query);
    if(!$result)
        $message="Error while executing query.<br/>sql Error: ";
    else
        return $result;

}
function closedb()
{
    global $conn;
    if(!$conn)
    pg_close($conn);
}
?>
