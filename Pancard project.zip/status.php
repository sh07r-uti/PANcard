<?php
$json = '{"100":"Success.","101":"Failed","102":"LogIn Successfully.","103":"Already exists.","404":"Enter correct username or password.",
		   "105":"Upload Successfully","106":"Enter data in all Field.","107":"Upload Error.","108":"Error.","109":"LogIn Failed.","110":"Insert Successfully.",
		   "111":"Insert Error.","112":"Password Change Successfully.","113":"Password Does Not Match.","114":"Mail Send Successfully.","115":"Mail Id Does Not Exists.",
		   "116":"Delete Successfully","117":"Branch Id Does Not Exits","118":"Update Successfully","119":"Update Error"
		   }';

$status=json_decode($json);




function showStatus($state,$data,$mesg)
	{
		$status=array("Status"=>$state,"Result"=>$data,"Mesg"=>$mesg);
		$status1=str_replace('\\', '', json_encode($status,true));
        echo $status1."<br>";
		  
	}




?>