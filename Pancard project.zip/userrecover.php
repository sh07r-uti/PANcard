<?php

include "connection.php";

	     $email=$_POST['email'];  
	     $query="select email from signup where email='$email' and status=0";
         $execute=mysql_query($query,$con);
         if(mysql_num_rows($execute)>0)
{
			 $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%&*_";
             $password = substr( str_shuffle( $chars ), 0, 8 );
			 $password1=md5($password);
			  
			  //$password1= md5($password);
              $query1 = mysql_query("UPDATE signup SET password='$password1',conform_password='$password1' WHERE email='$email'");
              if($query1)
		{
              $to = $email;
              $subject = 'Your New Password...';
              $message = 'Hello User Your new password : '.$password.'E-mail: '.$email.'Now you can login with this email and password.';
			  
              if(mail($to, $subject, $message ))
            {
              
			   echo "<html><body background='img/body-bg.png'><script>alert('Password Change Successfully.');</script></body></html>";
			   header("refresh:2; url=apply_online.html");
			  
            }
			   
	    }
}	 
        else
    {
       
		echo "<html><body background='img/body-bg.png'><script>alert('Invalid E-mail Address.');</script></body></html>";
        header("refresh:2; url=user_recover.html");
    }
			
    mysql_close($con);
?>