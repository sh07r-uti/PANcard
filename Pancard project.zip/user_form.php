<?php 
session_start();
//include "connection.php";
$con=mysqli_connect("localhost","root","","pancard") or die("nay hot connection");

if(!isset($_SESSION['id']))
{
header("location:apply_online.html");
}
else{
       //$id=$_GET['id'];
       $user_id=$_SESSION['r'];
	   $query=mysqli_query($con,"select f_name,l_name,email,gender,date from signup where ");
//echo"q". $_SESSION['r'];
	   $f_name=pg_result($query,0,0);
	   $l_name=pg_result($query,0,1);
	   $email=pg_result($query,0,2);
	   $gender=pg_result($query,0,3);
	   $dob=pg_result($query,0,4);
	
           	   
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Apply PanCard</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet'  type='text/css'>
	<style type="text/css">
	
	
	
	</style>
	
  </head>

  <body role="document">

  
    <div class="container container1">

        <div class="page-header page-header1 ">
	       <ul class="nav nav-pills pull-right">
            <li><a href="user_home.php">Home</a></li>
            <li  class="active"><a href="user_form.php">Apply</a></li>
            <li><a href="track.php">Track</a></li>
			 <li><a href="logout.php">LogOut</a></li>
          </ul>
	  
	  
        <h2>Pan Card Online</h2>
      </div> 
	  
	
	<form class="well form-horizontal" action="adduser_form.php" method="post"  id="contact_form">
<fieldset>

<!-- Form Name -->
<legend>Apply For Pancard!</legend>

<!-- Text input-->
                <div class="row">
			                 	<!-- First part-->
                               <div class="col-xs-12 col-sm-6 col-md-6">
			    					
									<div class="form-group">
                                    <label class="col-md-4 control-label">First Name</label>  
                                     <div class="col-md-6 inputGroupContainer">
                                     <div class="input-group">
                                     <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                     <input  name="f_name" value="<?php echo $f_name; ?>"  class="form-control"  type="text" required autofocus readonly>
                                     </div>
                                     </div>
                                     </div>
									 
									 <div class="form-group">
                                    <label class="col-md-4 control-label">Middle Name</label>  
                                     <div class="col-md-6 inputGroupContainer">
                                     <div class="input-group">
                                     <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                     <input  name="m_name" placeholder="Middle Name" class="form-control"  type="text"  required autofocus>
                                     </div>
                                     </div>
                                     </div>
									
									
									
									 <div class="form-group">
									<label class="col-md-4 control-label" >Last Name</label> 
									<div class="col-md-6 inputGroupContainer">
									<div class="input-group">
									<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
									<input name="l_name"  value="<?php echo $l_name; ?>" class="form-control"  type="text" required autofocus readonly>
									</div>
									</div>
								    </div>	
									
									
									
									
									
								<div class="form-group">
									<label class="col-md-4 control-label">Mobile</label>  
									<div class="col-md-6 inputGroupContainer">
									<div class="input-group">
									<span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
									<input name="mobile" placeholder="(845)555-1212" class="form-control" type="text" maxlength="10" required autofocus>
									</div>
									</div>
								</div>
								
								
								<div class="form-group">
									<label class="col-md-4 control-label">Gender</label>  
									<div class="col-md-6 inputGroupContainer">
									<div class="input-group">
									<span class="input-group-addon"><i class="glyphicon glyphicon-record"></i></span>
									<input name="gender" value="<?php echo $gender; ?>" class="form-control" type="text" required autofocus readonly>
									</div>
									</div>
								</div>
								
								
								
								<div class="form-group">
									<label class="col-md-4 control-label">DD.Number</label>  
									<div class="col-md-6 inputGroupContainer">
									<div class="input-group">
									<span class="input-group-addon"><i class="glyphicon glyphicon-stats"></i></span>
									<input name="dd_number" placeholder="DD Number" class="form-control" type="text" maxlength="6" required autofocus>
									</div>
									</div>
								</div>
								
								
								<div class="form-group">
									
									<input name="user_id" value="<?php echo $user_id; ?>" class="form-control" type="hidden">
									
								</div>
								
									
									
								
									
			    				</div>
								
								
								
								
								
								
								
								<!-- second part-->
                               <div class="col-xs-12 col-sm-6 col-md-6">
			    					
                               	        <div class="form-group">
										<label class="col-md-4 control-label">E-Mail</label>  
										<div class="col-md-6 inputGroupContainer">
										<div class="input-group">
										<span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
										<input name="email"  value="<?php echo $email; ?>" class="form-control"  type="text" required autofocus readonly>
										</div>
										</div>
									   </div>                
								
								
								<div class="form-group">
                                    <label class="col-md-4 control-label">Date Of Birth</label>  
                                     <div class="col-md-6 inputGroupContainer">
                                     <div class="input-group">
                                     <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                     <input  name="dob" placeholder="Birth Date" class="form-control"  type="date"  required autofocus>
                                     </div>
                                     </div>
                                     </div>
								
								

								
								
								
								<div class="form-group">
									<label class="col-md-4 control-label">Permant Address</label>  
									<div class="col-md-6 inputGroupContainer">
									<div class="input-group">
									<span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
									<input name="address" placeholder="Address" class="form-control" type="text">
									</div>
									</div>
								</div>
								
								
								<div class="form-group">
									<label class="col-md-4 control-label">Occupation</label>  
									<div class="col-md-6 inputGroupContainer">
									<div class="input-group">
									<span class="input-group-addon"><i class="glyphicon glyphicon-tasks"></i></span>
									<input name="occupation" placeholder="Occupation" class="form-control" type="text" required autofocus>
									</div>
									</div>
								</div>
								
							<div class="form-group">
									<label class="col-md-4 control-label">Upload profile photo</label>  
									<div class="col-md-6 inputGroupContainer">
									<div class="input-group">
									<input type="file" name="profile" class="filestyle" data-buttonName="btn-primary" required autofocus>
									</div>
									</div>
								</div>
								
								
								
								<div class="form-group">
									<label class="col-md-4 control-label">Upload Document</label>  
									<div class="col-md-6 inputGroupContainer">
									<div class="input-group">
									<input type="file" name="document" class="filestyle" data-buttonName="btn-primary" required autofocus>
									</div>
									</div>
								</div>
								
								
								
								
								
			    				</div>
                 </div>
				 
				 
				
				 
				 



<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-4 col-md-offset-2">
    <button type="submit" class="btn btn-primary" >Send <span class="glyphicon glyphicon-send"></span></button>
  </div>
</div>

</fieldset>
</form>

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	  
	  
      <div class="navbar navbar-inverse my-footer">
        <div class="container-fluid">
            <div class="row">
		
               <div class="col-sm-4 col-sm-offset-4 text-center">
                <p class="navbar-text text-center">2015 © pancard. All rights reserved.</p>
			   </div>	
            </div>
			
			
			 <div class="row">
		 <div class="col-sm-7 col-sm-offset-2 text-center">
                      
                          <hr>
						<ul class="list-inline center-block">
						<li><a href="http://facebook.com"><img src="assets/soc_fb.png"></a></li>
						<li><a href="http://twitter.com"><img src="assets/soc_tw.png"></a></li>
						<li><a href="http://google.com"><img src="assets/soc_gplus.png"></a></li>
						<li><a href="http://pinterest.com"><img src="assets/soc_lik.png"></a></li>
						</ul>
  	                </div><!--/col-->
              
			   </div>	
            </div>
			
			
        </div>
	
    </div> <!-- /container    <img src="img/pancard.jpg" class="img-responsive" alt="pancard">    -->

	

	


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/docs.min.js"></script>
	<script type="text/javascript" src="js/bootstrap-filestyle.min.js"> </script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
<?php } ?>
