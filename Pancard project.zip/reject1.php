<?php
include "connection.php";

	     $id=$_GET['id'];
         $status=4;		 
	    
              $query1 = mysql_query("UPDATE userform SET status='$status' WHERE id='$id'");
              if($query1)
		{
              
			   echo "<html><body background='img/body-bg.png'><script>alert('Successfully Reject.');</script></body></html>";
			   header("refresh:1; url=reverification.php");
	    }else
		{
		       
			    echo "<html><body background='img/body-bg.png'><script>alert('Reject Error');</script></body></html>";
			   header("refresh:1; url=reverification.php");
		}
 
     
			
    mysql_close($con);
?>