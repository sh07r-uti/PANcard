<?php

//include "connection.php";
//include "status.php";
$con=mysqli_connect("localhost","root","","pancard") or die("nay hot connection");
$id=1;
    $f_name=$_POST['f_name'];
	$l_name=$_POST['l_name'];
	$email=$_POST['email'];
	$message=$_POST['message'];
	
	 
	 
	
      $insert="insert into feedback values('$id','$f_name','$l_name','$email','$message')";
	  $res=mysqli_query($con,$insert);
	  
      if($res)
     {
		$id++;
		echo "<html><body background='img/body-bg.png'><script>alert('Successfully Insert');</script></body></html>";
	    header("refresh:1; url=feedback.html");
		exit();
	 }
    else
    {
		echo "<html><body background='img/body-bg.png'><script>alert('Insert Error');</script></body></html>";
		header("refresh:1; url=feedback.html");

    }
			
    pg_close($con);



?>
