<?php
session_start();
//include "connection.php";
$con=mysqli_connect("localhost","root","","pancard") or die("nay hot connection");
             $email=$_POST['email'];
             $pass=$_POST['password'];
             $password=md5($pass);

             $query="select id,email,password from signup where email='$email' and password='$password'";

             $execute=mysqli_query($con,$query);
	 $r=mysqli_fetch_array($execute);
			$_SESSION['r']=$r['id'];
       
      if($r['email']==$email && $r['password']==$password)
    {   
		  
        $user_id=pg_result($execute,0,0);
		 $id=session_id();
		 $_SESSION['id']=$id;
		 $_SESSION['user_id']=$user_id;
		header("location:user_form.php");
		
	}
else
    {
	  
		echo "<html><body background='img/body-bg.png'><script>alert('Login Failed');</script></body></html>";
        header("refresh:0;url=apply_online.html");
    }

?>
