
<?php

//include "connection.php";
$con=pg_connect("host=localhost dbname=pancard user=postgres") or die("nay hot connection");

	     $id=$_GET['id'];
		
              $query1 = pg_query("delete from section WHERE id='$id'");
              if($query1)
		{
              
			  header("location:modifysection.php");
			  
	    }else
		{
		       
			  echo "<html><body background='img/body-bg.png'><script>alert('Delete Error.');</script></body></html>";
               header("refresh:1; url=modifysection.php");
		}
	 
       
    mysql_close($con);
?>
