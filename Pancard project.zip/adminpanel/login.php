<?php
session_start();
//include "connection.php";
$con=pg_connect("host=localhost dbname=pancard user=postgres") or die("nay hot connection");

    $email=$_POST['email'];
    $password=$_POST['password'];
    $department=$_POST['department'];
	
	
	
	//Administrator Login
	  if($department=="admin")
	  {
      $query="select name from admin where email='$email' and password='$password'";
      $execute=pg_query($query);
      if($e=pg_fetch_assoc($execute))
        {     
		 $id=session_id();
		 $_SESSION['id']=$id;
		header("location:section.php");
	  }
    
	  }	
	  	  
	  //verification Department
	  if($department=="section1")
	  {
             $section="section1";
             $query="select id from section where email='$email' and password='$password' and section='$section'";
             $execute=pg_query($query);
			 
       
      if($e=pg_fetch_assoc($execute))
       {     
         $user_id=pg_result($execute,0,0);
		 $id=session_id();
		 $_SESSION['id']=$id;
		 $_SESSION['user_id']=$user_id;
		 header("location:/civilregistration/section1.php");
		
	    }
		
		  
	  }
	  
	  
	  //Reverification Department
	   if($department=="section2")
	  {
		  $section="section2";
             $query="select id from section where email='$email' and password='$password' and section='$section'";
             $execute=pg_query($query);
			 
       
      if($e=pg_fetch_assoc($execute))
    {     
         $user_id=pg_result($execute,0,0);
		 $id=session_id();
		 $_SESSION['id']=$id;
		 $_SESSION['user_id']=$user_id;
		header("location:/civilregistration/section2.php");
		
	}
		  
	  }
	  
	  
	  //Income Tax Department
	   if($department=="section3")
	  {
		  
		   $section="section3";
             $query="select id from section where email='$email' and password='$password' and section='$section'";
             $execute=pg_query($query);
			 
       
      if($e=pg_fetch_assoc($execute))
    {     
         $user_id=pg_result($execute,0,0);
		 $id=session_id();
		 $_SESSION['id']=$id;
		 $_SESSION['user_id']=$user_id;
		header("location:/civilregistration/section3.php");
		
	}
	  }
	  else
	  {
		  
		  echo "<html><body background='img/body-bg.png'><script>alert('Login Failed');</script></body></html>";
          header("refresh:0;url=login.html");
		  
	  }
	  
	  
	

//pg_close($con);
?>
