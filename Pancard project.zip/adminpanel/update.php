
<?php 
session_start();
//include "connection.php";
$con=pg_connect("host=localhost dbname=pancard user=postgres") or die("nay hot connection");

if(!isset($_SESSION['id']))
{
header("location:login.html");
}
else{
       
$id=$_GET['id'];

	   
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>Admin Panel</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

  <section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a href="#" class="logo"><b>Pan_Card</b></a>
            <!--logo end-->
            
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="logout.php">Logout</a></li>
            	</ul>
            </div>
        </header>
      <!--header end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
              	  <p class="centered"><img src="assets/img/user1.png" class="img-circle" width="60"></p>
              	  <h5 class="centered">Admin</h5>
              	  	
                  <li class="mt">
                      <a href="section.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Section SignUp</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a href="signupuser.php" >
                          <i class="fa fa-desktop"></i>
                          <span>SignUp Users</span>
                      </a> 
                  </li>
				   <li class="sub-menu">
                      <a href="applyuser.php" >
                          <i class="fa fa-desktop"></i>
                          <span>Apply Users</span>
                      </a> 
                  </li>
                    <li class="sub-menu">
                      <a href="modifysection.php" >
                          <i class="fa fa-desktop"></i>
                          <span>Section Update</span>
                      </a> 
                  </li>
                  <li class="sub-menu">
                      <a href="feedback.php" >
                          <i class="fa fa-desktop"></i>
                          <span>FeedBack</span>
                      </a> 
                  </li>
                <li class="sub-menu">
                      <a href="contact.php" >
                          <i class="fa fa-desktop"></i>
                          <span>Contact US</span>
                      </a> 
                  </li>
                 
                 
                 

              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
          	<h3><i class="fa fa-angle-right"></i> Update Sections</h3>
		  		<div class="row mt">
			  		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <div class="content-panel">
                     
				
				
				
				
				<form class="form-horizontal" action="updatesection.php" method="post"  id="contact_form">
<fieldset>

<!-- Form Name -->


<!-- Text input-->

                <div class="row">
			                 	<!-- First part-->
                               <div class="col-xs-12 col-sm-6 col-md-6">
			    					
									<div class="form-group">
                                    <label class="col-md-4 control-label">First Name</label>  
                                     <div class="col-md-6 inputGroupContainer">
                                     <div class="input-group">
                                     <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                     <input  name="f_name" placeholder="First Name" class="form-control"  type="text" required autofocus>
                                     </div>
                                     </div>
                                     </div>
									 
									 
									
									
									
									 <div class="form-group">
									<label class="col-md-4 control-label" >Last Name</label> 
									<div class="col-md-6 inputGroupContainer">
									<div class="input-group">
									<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
									<input name="l_name"  placeholder="Last Name" class="form-control"  type="text" required autofocus>
									</div>
									</div>
								    </div>	
									
									
									
									
									
								<div class="form-group">
									<label class="col-md-4 control-label">Mobile</label>  
									<div class="col-md-6 inputGroupContainer">
									<div class="input-group">
									<span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
									<input name="mobile" placeholder="(845)555-1212" class="form-control" type="text" maxlength="10" required autofocus>
									</div>
									</div>
								</div>
								
								
								<div class="form-group">
									<label class="col-md-4 control-label">Gender</label>  
									<div class="col-md-6 inputGroupContainer">
									<div class="input-group">
									
														
                               <label class="radio-inline">
                                  <input type="radio" name="sex" id="inlineCheckbox1" value="male" />
                                 <b> Male</b>
                               </label>
                              <label class="radio-inline">
                                   <input type="radio" name="sex" id="inlineCheckbox2" value="female" />
                                   <b> Female</b>
                               </label>
									</div>
									</div>
								</div>
								
								
			                    <div class="form-group">
								<input name="id" class="form-control" type="hidden" value="<?php echo $id; ?>">
								</div>
								
								
								
								
									
			    				</div>
								
								
								
								
								
								
								
								<!-- second part-->
                               <div class="col-xs-12 col-sm-6 col-md-6">
			    					
                               	        <div class="form-group">
										<label class="col-md-4 control-label">E-Mail</label>  
										<div class="col-md-6 inputGroupContainer">
										<div class="input-group">
										<span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
										<input name="email" placeholder="Email" class="form-control"  type="text" required autofocus>
										</div>
										</div>
									   </div>                
								
								
								<div class="form-group">
                                    <label class="col-md-4 control-label">Date Of Birth</label>  
                                     <div class="col-md-6 inputGroupContainer">
                                     <div class="input-group">
                                     <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                     <input  name="dob" placeholder="Birth Date" class="form-control"  type="date"  required autofocus>
                                     </div>
                                     </div>
                                     </div>
								
								

								
								
								
								<div class="form-group">
									<label class="col-md-4 control-label">Permant Address</label>  
									<div class="col-md-6 inputGroupContainer">
									<div class="input-group">
									<span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
									<input name="address" placeholder="Address" class="form-control" type="text">
									</div>
									</div>
								</div>
								
								
								<div class="form-group"> 
										<label class="col-md-4 control-label">Section</label>
										<div class="col-md-6 selectContainer">
										<div class="input-group">
										<span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
										<select name="section" class="form-control selectpicker" required autofocus>
										<option value=" " >Please select your section</option>
											<option>section1</option>
											<option>section2</option>
											<option >section3</option>
											
															</select>
													</div>
												</div>
								</div>
								
								
								
			    				</div>
								
								
                 </div>
				 
				 
			<hr>
<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label"></label>
  <div class="col-md-4 col-md-offset-2">
    <button type="submit" class="btn btn-primary" >Send <span class="glyphicon glyphicon-send"></span></button>
	
  </div>
</div>

</fieldset>
</form>
		
				
				
				
					  
                  </div><!-- /content-panel -->
               </div><!-- /col-lg-4 -->			
		  	
		</section><! --/wrapper -->
      </section><!-- /MAIN CONTENT -->
	  
	  
	  
	  
	  
	  
      <!--footer start-->
      <footer class="site-footer">
          <div class="text-center">
              2015 © pancard. All rights reserved.
              <a href="section.php" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>
	 
  </section>
 
      <!--footer end-->
    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="assets/js/jquery.ui.touch-punch.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>

    <!--script for this page-->
    
  <script>
      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
<?php }?>
