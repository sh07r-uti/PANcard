
<?php 
session_start();
//include "connection.php";
$con=pg_connect("host=localhost dbname=pancard user=postgres") or die("nay hot connection");

if(!isset($_SESSION['id']))
{
header("location:login.html");
}
else{
           	   
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Dashboard">
    <meta name="keyword" content="Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">

    <title>SignUp Users</title>

    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">


    <link href="assets/css/table-responsive.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	
	
	<style type="text/css">
	
	h2 {
  text-align: center;
}

table caption {
	padding: .3em 0;
}

@media screen and (max-width: 767px) {
  table caption {
    border-bottom: 1px solid #ddd;
  }
}

.p {
  text-align: center;
  padding-top: 140px;
  font-size: 14px;
}
	
	</style>
	
  </head>

  <body>

  <section id="container">
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
            <a href="#" class="logo"><b>Pan_Card</b></a>
            <!--logo end-->
            
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="logout.php">Logout</a></li>
            	</ul>
            </div>
        </header>
      <!--header end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
              	  <p class="centered"><img src="assets/img/user1.png" class="img-circle" width="60"></p>
              	  <h5 class="centered">Admin</h5>
				  
              	 <li class="mt">
                      <a href="section.php">
                          <i class="fa fa-dashboard"></i>
                          <span>Section SignUp</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a href="signupuser.php" >
                          <i class="fa fa-desktop"></i>
                          <span>SignUp Users</span>
                      </a> 
                  </li>
				   <li class="sub-menu">
                      <a href="applyuser.php" >
                          <i class="fa fa-desktop"></i>
                          <span>Apply Users</span>
                      </a> 
                  </li>
                    <li class="sub-menu">
                      <a href="modifysection.php" >
                          <i class="fa fa-desktop"></i>
                          <span>Section Update</span>
                      </a> 
                  </li>
                  <li class="sub-menu">
                      <a href="feedback.php" >
                          <i class="fa fa-desktop"></i>
                          <span>FeedBack</span>
                      </a> 
                  </li>
                <li class="sub-menu">
                      <a href="contact.php" >
                          <i class="fa fa-desktop"></i>
                          <span>Contact US</span>
                      </a> 
                  </li>

                 
                 
                 
                 

              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper">
          	<h3><i class="fa fa-angle-right"></i> SignUp Users</h3>
		  		<div class="row mt">
			  		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                      <div class="content-panel">
                      <h4><i class="fa fa-angle-right"></i> SignUp Users</h4>
					  
					  <div class="table-responsive">
        <table summary="This table shows how to create responsive tables using Bootstrap's default functionality" class="table table-bordered table-hover">
         
         <thead>
                              <tr>
                                  <th>ID</th>
                                  <th>First Name</th>
                                  <th>Last Name</th>
                                  <th>Email</th>
                                  <th>Date</th>
                                  <th>Gender</th>
                                 
                              </tr>
                              </thead>
                          
                              <tbody>
							   <?php $query=pg_query("select * from signup"); 
							   $i=0;
	                            while($row = pg_fetch_array($query)){ $i++;  ?>
                              <tr>
                                  <td><?php echo $i; ?></td>
								  <td><?php echo $row['f_name']; ?></td>
								  <td><?php echo $row['l_name']; ?></td>
								  <td><?php echo $row['email']; ?></td>
								  <td><?php echo $row['date']; ?></td>
								  <td><?php echo $row['gender']; ?></td>
                                  
                                  
                              </tr>
								<?php }?>
								 </tbody>
         
        </table>
      </div><!--end of .table-responsive-->
					  
					  
                  </div><!-- /content-panel -->
               </div><!-- /col-lg-4 -->			
		  	
		</section><! --/wrapper -->
      </section><!-- /MAIN CONTENT -->
	  
	  
	  
	  
	  
	  
	  
	  
      <!--footer start-->
      <footer class="site-footer">
          <div class="text-center">
              2015 © pancard. All rights reserved.
              <a href="signupuser.php" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="assets/js/jquery.ui.touch-punch.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>

    <!--script for this page-->
    
  <script>
      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

  </body>
</html>
<?php }?>
