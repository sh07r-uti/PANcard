<?php

//include "connection.php";
$con=pg_connect("host=localhost dbname=pancard user=postgres") or die("nay hot connection");



     $f_name=$_POST['f_name'];
	 $l_name=$_POST['l_name'];
	 $email=$_POST['email'];
	 $id=$_POST['id'];
     $p_address=$_POST['address'];
	 $dob=$_POST['dob'];
	 $mobile=$_POST['mobile'];
	
	 $gender=$_POST['sex'];
	 $section=$_POST['section'];
	
     $sql="UPDATE section SET f_name='$f_name',l_name='$l_name',email='$email',mobile='$mobile',dob='$dob',gender='$gender',address='$p_address',section='$section' WHERE id='$id'";
     $result=pg_query($sql);


            if($result){
			   echo "<html><body background='img/body-bg.png'><script>alert('Update Successfully.');</script></body></html>";
               header("refresh:1; url=modifysection.php"); 
               }

             else {
			    echo "<html><body background='img/body-bg.png'><script>alert('Update Error.');</script></body></html>";
               header("refresh:1; url=modifysection.php");
                    }

?> 
