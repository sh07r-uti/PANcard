<?php

//include "connection.php";
//include "status.php";
$con=pg_connect("host=localhost dbname=pancard user=postgres") or die("nay hot connection");

$id=2;
    $f_name=$_POST['f_name'];
	$l_name=$_POST['l_name'];
	$email=$_POST['email'];
	
	$p_address=$_POST['address'];
	$dob=$_POST['dob'];
	$mobile=$_POST['mobile'];
	
	$gender=$_POST['gender'];
	$section=$_POST['section'];
	$status=0;
	 
	         $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%&*_";
             $password = substr( str_shuffle( $chars ), 0, 8 );
	
      $insert="insert into section values('$id','$f_name','$l_name','$email','$password','$mobile','$dob','$gender','$p_address','$section','$status')";
	  $res=pg_query($insert);
	  
      if($res)
     {
	$id++;	
		echo "<html><body background='img/body-bg.png'><script>alert('Record Insert Successfully');</script></body></html>";
	    header("refresh:1; url=section.php");
		exit();
	 }
    else
    {
		echo "<html><body background='img/body-bg.png'><script>alert('Insert Error');</script></body></html>";
		header("refresh:1; url=section.php");

    }
			
  //  pg_close($con);



?>
