<?php
$dbhost="localhost";
$root="root";
$dbpassword="";
$dbname="pancard";

$con=mysql_connect($dbhost,$root,$dbpassword) or die("Error in Connection");
mysql_select_db($dbname,$con);

?>