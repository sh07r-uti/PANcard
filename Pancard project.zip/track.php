<?php 
session_start();
//include "connection.php";
$con=mysqli_connect("localhost","root","","pancard") or die("nay hot connection");


if(!isset($_SESSION['id']))
{
header("location:apply_online.html");
}
else{
       //$id=$_GET['id'];
       $user_id=$_SESSION['r'];
	   $query=mysqli_query($con,"select status from userform where user_id='$user_id'");
	   $status=pg_result($query,0,0);
	   
           	   
?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Track Pancard</title>

	
    <link rel="stylesheet" type="text/css" href="track/bootstrap/css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="track/font-awesome/css/font-awesome.min.css" />

    <script type="text/javascript" src="track/js/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="track/bootstrap/js/bootstrap.min.js"></script>
	
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet'  type='text/css'>
	<style type="text/css">
	
	
	
	</style>
	
  </head>

  <body role="document">

  
    <div class="container">

       <div class="page-header">
   
   
    
	       <ul class="nav nav-pills pull-right">
            <li><a href="user_home.php">Home</a></li>
            <li><a href="user_form.php">Apply</a></li>
            <li class="active"><a href="track.php">Track</a></li>
			 <li><a href="logout.php">LogOut</a></li>
          </ul>
	  
	  
        <h2>Pan Card Online</h2>
     
   
   
</div>

<!-- Steps Progress and Details - START -->
<?php
if(isset($status))
{

 if($status==0){?>
    <div class="row">
	   <div class="col-md-10 col-md-offset-1">
        <div class="progress" id="progress1">
            <div class="progress-bar" role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="width: 25%;">
            </div>
            <span class="progress-type">Overall Progress</span>
            <span class="progress-completed">25%</span>
        </div>
		</div>
    </div>
<?php }?>
<?php if($status==1){?>
    <div class="row">
	   <div class="col-md-10 col-md-offset-1">
        <div class="progress" id="progress1">
            <div class="progress-bar" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%;">
            </div>
            <span class="progress-type">Overall Progress</span>
            <span class="progress-completed">50%</span>
        </div>
		</div>
    </div>
<?php }?>

<?php if($status==2){?>
    <div class="row">
	   <div class="col-md-10 col-md-offset-1">
        <div class="progress" id="progress1">
            <div class="progress-bar" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100" style="width: 75%;">
            </div>
            <span class="progress-type">Overall Progress</span>
            <span class="progress-completed">75%</span>
        </div>
		</div>
    </div>
<?php }?>
<?php if($status==3){?>
    <div class="row">
	   <div class="col-md-10 col-md-offset-1">
        <div class="progress" id="progress1">
            <div class="progress-bar" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%;">
            </div>
            <span class="progress-type">Overall Progress</span>
            <span class="progress-completed">100%</span>
        </div>
		</div>
    </div>
<?php }?>
	
	
	
    <div class="row">
        <div class="row step">
		
		
		
		<?php if($status==0){?>
            <div id="div1" class="col-md-2 col-md-offset-1">
                <span class="fa fa-cloud-download"></span>
                <p>USer Section</p>
            </div>

            <div class="col-md-2 activestep">
                <span class="fa fa-pencil"></span>
                <p>Verification</p>
            </div>
			
            <div class="col-md-2 ">
                <span class="fa fa-refresh"></span>
                <p>Reverification</p>
            </div>
			
            <div class="col-md-2 ">
                <span class="fa fa-dollar"></span>
                <p>Income Tax</p>
            </div>
			
            <div class="col-md-2">
                <span class="fa fa-cloud-upload"></span>
                <p>Delivery</p>
            </div>
			<?php }?>
			
			<?php if($status==1){?>
            <div id="div1" class="col-md-2 col-md-offset-1">
                <span class="fa fa-cloud-download"></span>
                <p>USer Section</p>
            </div>

            <div class="col-md-2">
                <span class="fa fa-pencil"></span>
                <p>Verification</p>
            </div>
			
            <div class="col-md-2 activestep">
                <span class="fa fa-refresh"></span>
                <p>Reverification</p>
            </div>
			
            <div class="col-md-2 ">
                <span class="fa fa-dollar"></span>
                <p>Income Tax</p>
            </div>
			
            <div class="col-md-2">
                <span class="fa fa-cloud-upload"></span>
                <p>Delivery</p>
            </div>
			<?php }?>
			
			<?php if($status==2){?>
            <div id="div1" class="col-md-2 col-md-offset-1">
                <span class="fa fa-cloud-download"></span>
                <p>USer Section</p>
            </div>

            <div class="col-md-2">
                <span class="fa fa-pencil"></span>
                <p>Verification</p>
            </div>
			
            <div class="col-md-2">
                <span class="fa fa-refresh"></span>
                <p>Reverification</p>
            </div>
			
            <div class="col-md-2 activestep">
                <span class="fa fa-dollar"></span>
                <p>Income Tax</p>
            </div>
			
            <div class="col-md-2">
                <span class="fa fa-cloud-upload"></span>
                <p>Delivery</p>
            </div>
			<?php }?>
			
			<?php if($status==3){?>
            <div id="div1" class="col-md-2 col-md-offset-1">
                <span class="fa fa-cloud-download"></span>
                <p>USer Section</p>
            </div>

            <div class="col-md-2">
                <span class="fa fa-pencil"></span>
                <p>Verification</p>
            </div>
			
            <div class="col-md-2">
                <span class="fa fa-refresh"></span>
                <p>Reverification</p>
            </div>
			
            <div class="col-md-2">
                <span class="fa fa-dollar"></span>
                <p>Income Tax</p>
            </div>
			
            <div class="col-md-2 activestep">
                <span class="fa fa-cloud-upload"></span>
                <p>Delivery</p>
            </div>
			<?php }?>
			
				
			
		
            
        </div>
    </div>
	
	
	
	<?php if($status==4){?>
    <div class="row">
        <div class="row step">
	      <div class="col-md-2 col-md-offset-5 activestep">
                <span class="fa fa-cloud-upload"></span>
                <p>Rejected</p>
            </div>
        </div>
    </div>
	<?php }?>
	
	<?php if($status==0){?>
    <div class="row setup-content step activeStepInfo" id="step-2">
        <div class="col-xs-12">
            <div class="col-md-12 text-center">
                <h1>Verification Department</h1>
                <h3 class="underline">Instructions</h3>
                Fill out the application. 
                Make sure to leave no empty fields. 
            </div>
        </div>
    </div>
	<?php } ?>
	
	
	<?php if($status==1){?>
    <div class="row setup-content step activeStepInfo" id="step-3">
        <div class="col-xs-12">
            <div class="col-md-12 text-center">
                <h1>Reverification Department</h1>
                <h3 class="underline">Instructions</h3>
                Check to ensure that all data entered is valid. 
            </div>
        </div>
    </div>
	<?php } ?>
	
	<?php if($status==2){?>
    <div class="row setup-content step activeStepInfo" id="step-4">
        <div class="col-xs-12">
            <div class="col-md-12 text-center">
                <h1>Income Tax Department</h1>
                <h3 class="underline">Instructions</h3>
                Pay the application fee. 
                This can be done either by entering your card details, or by using Paypal.
            </div>
        </div>
    </div>
	<?php } ?>
	
	
    <?php if($status==3){?>
    <div class="row setup-content step activeStepInfo" id="step-5">
        <div class="col-xs-12">
            <div class="col-md-12 text-center">
                <h1>Delivery</h1>
                <h3 class="underline">Instructions</h3>
                Upload the application. 
                This may require a confirmation email.
            </div>
        </div>
    </div>
    <?php } ?>
	
	
    
			<?php if($status==4){?>
			<div class="row setup-content step activeStepInfo" id="step-6">
        <div class="col-xs-12">
            <div class="col-md-12 text-center">
                <h1>Reject</h1>
                <h3 class="underline">Instructions</h3>
                Your Request is rejected,Try Again. 
               
            </div>
        </div>
    </div>
			
		<?php }?>
	
<?php } ?>
	
	

<style>
.hiddenStepInfo {
    display: none;
}

.activeStepInfo {
    display: block !important;
}

.underline {
    text-decoration: underline;
}

.step {
    margin-top: 27px;
}

.progress {
    position: relative;
    height: 25px;
}

.progress > .progress-type {
    position: absolute;
    left: 0px;
    font-weight: 800;
    padding: 3px 30px 2px 10px;
    color: rgb(255, 255, 255);
    background-color: rgba(25, 25, 25, 0.2);
}

.progress > .progress-completed {
    position: absolute;
    right: 0px;
    font-weight: 800;
    padding: 3px 10px 2px;
}

.step {
    text-align: center;
}

.step .col-md-2 {
    background-color: #fff;
    border: 1px solid #C0C0C0;
    border-right: none;
}

.step .col-md-2:last-child {
    border: 1px solid #C0C0C0;
}

.step .col-md-2:first-child {
    border-radius: 5px 0 0 5px;
}

.step .col-md-2:last-child {
    border-radius: 0 5px 5px 0;
}

.step .col-md-2:hover {
    color: #F58723;
    cursor: pointer;
}

.step .activestep {
    color: #F58723;
    height: 100px;
    margin-top: -7px;
    padding-top: 7px;
    border-left: 6px solid #5CB85C !important;
    border-right: 6px solid #5CB85C !important;
    border-top: 3px solid #5CB85C !important;
    border-bottom: 3px solid #5CB85C !important;
    vertical-align: central;
}

.step .fa {
    padding-top: 15px;
    font-size: 40px;
}
</style>

<script type="text/javascript">
    function resetActive(event, percent, step) {
        $(".progress-bar").css("width", percent + "%").attr("aria-valuenow", percent);
        $(".progress-completed").text(percent + "%");

        $("div").each(function () {
            if ($(this).hasClass("activestep")) {
                $(this).removeClass("activestep");
            }
        });

        if (event.target.className == "col-md-2") {
            $(event.target).addClass("activestep");
        }
        else {
            $(event.target.parentNode).addClass("activestep");
        }

        hideSteps();
        showCurrentStepInfo(step);
    }

    function hideSteps() {
        $("div").each(function () {
            if ($(this).hasClass("activeStepInfo")) {
                $(this).removeClass("activeStepInfo");
                $(this).addClass("hiddenStepInfo");
            }
        });
    }

    function showCurrentStepInfo(step) {        
        var id = "#" + step;
        $(id).addClass("activeStepInfo");
    }
</script>

<!-- Steps Progress and Details - END -->
	  
	
	  
      <div class="navbar navbar-inverse my-footer">
        <div class="container-fluid">
            <div class="row">
		
               <div class="col-sm-4 col-sm-offset-4 text-center">
                <p class="navbar-text text-center">2015 © pancard. All rights reserved.</p>
			   </div>	
            </div>
			
			
			 <div class="row">
		 <div class="col-sm-7 col-sm-offset-2 text-center">
                      
                          <hr>
						<ul class="list-inline center-block">
						<li><a href="http://facebook.com"><img src="assets/soc_fb.png"></a></li>
						<li><a href="http://twitter.com"><img src="assets/soc_tw.png"></a></li>
						<li><a href="http://google.com"><img src="assets/soc_gplus.png"></a></li>
						<li><a href="http://pinterest.com"><img src="assets/soc_lik.png"></a></li>
						</ul>
  	                </div><!--/col-->
              
			   </div>	
            </div>
			
			
        </div>
	
    </div> <!-- /container    <img src="img/pancard.jpg" class="img-responsive" alt="pancard">    -->

	

	


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/docs.min.js"></script>
	<script type="text/javascript" src="js/bootstrap-filestyle.min.js"> </script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
<?php } ?>
