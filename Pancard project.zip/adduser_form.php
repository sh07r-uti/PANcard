<?php
session_start();
//include "connection.php";
//include "status.php";

$con=mysqli_connect("localhost","root","","pancard") or die("nay hot connection");


    $f_name=$_POST['f_name'];
	$m_name=$_POST['m_name'];
	$l_name=$_POST['l_name'];
	$email=$_POST['email'];
	$p_address=$_POST['address'];
	$dob=$_POST['dob'];
	$mobile=$_POST['mobile'];
	$occuption=$_POST['occupation'];
	$dd_number=$_POST['dd_number'];
	//$date=$day."/".$month."/".$year;
	$profile=$_POST['profile'];
	$gender=$_POST['gender'];
	$document=$_POST['document'];
	$user_id=$_SESSION['r'];
	$status=0;
	$id=1;
	  $char1 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%&*_";
	  $char2="0123456789";
	  $request1= substr( str_shuffle( $char2 ), 0, 6 );
      $request2 = substr( str_shuffle( $char1 ), 0, 8 );
	  $request_id=$request2.$request1;
	
      $insert="insert into userform values('$user_id','$f_name','$m_name','$l_name','$dob','$gender','$email','$request_id','$p_address','$mobile','$occuption','$dd_number','$profile','$document','$user_id','$status')";
	  $res=mysqli_query($con,$insert);
//		  echo"insert into userform values('$id','$f_name','$m_name','$l_name','$dob','$gender','$email','$request_id','$p_address','$mobile','$occuption','$dd_number','$profile','$document','$user_id','$status')";
      if($res)
     {
		
		echo "<html><body background='img/body-bg.png'><script>alert('Record Insert Successfully');</script></body></html>";
	    header("refresh:1; url=user_home.php");
		exit();
	 }
    else
    {
//		echo "<html><body background='img/body-bg.png'><script>alert('Insert Error');</script></body></html>";
//		header("refresh:1; url=adduser_form.php");

    }
			
   // mysqli_close($con);



?>
