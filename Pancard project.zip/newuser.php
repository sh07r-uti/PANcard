<?php

//include "connection.php";
//include "status.php";
$con=mysqli_connect("localhost","root","","pancard") or die("nay hot connection");
$id=2;
    $f_name=$_POST['f_name'];
	$l_name=$_POST['l_name'];
	$email=$_POST['email'];
	$password1=$_POST['password'];
	$password=md5($password1);
	$conform_password1=$_POST['conform_password'];
	$conform_password=md5($conform_password1);
	$date=$_POST['date'];
	$gender=$_POST['sex'];
	$status=0;
	 
	 
	 $query="select email from signup where email='$email' and status=0";
         $execute=mysqli_query($con,$query);
         if(mysqli_num_rows($execute)>0)
			 
		  {
       
		echo "<html><body background='img/body-bg.png'><script>alert('Sorry This Email Id AllReady Exist.');</script></body></html>";
        header("refresh:2; url=newuser.html");
    }else
{
      $insert="insert into signup values('$id','$f_name','$l_name','$email','$password','$conform_password','$date','$gender','$status')";
	  $res=mysqli_query($con,$insert);
	  
      if($res)
     {
	$id=$id+1;	
		echo "<html><body background='img/body-bg.png'><script>alert('Account Create Successfully');</script></body></html>";
	    header("refresh:1; url=apply_online.html");
		exit();
	 }
    else
    {
		echo "<html><body background='img/body-bg.png'><script>alert('Account Not Create Successfully');</script></body></html>";
		header("refresh:1; url=newuser.html");

    }
}
	

   
	
	

			
//    mysqli_close($con);



?>
