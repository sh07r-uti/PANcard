<?php
$dbhost="localhost";
$root="root";
$dbpassword="";
$dbname="pancard";

$con=mysqli_connect("localhost","root","","pancard") or die("Error in Connection");
//mysqli_select_db($con);

?>