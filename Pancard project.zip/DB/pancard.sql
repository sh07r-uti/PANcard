-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 28, 2015 at 07:31 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pancard`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
`id` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`) VALUES
(5, 'sagar', 'sagarthombare71@gmail.com', 'creative');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us`
--

CREATE TABLE IF NOT EXISTS `contact_us` (
`c_id` int(4) NOT NULL,
  `f_name` varchar(20) NOT NULL,
  `l_name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` int(10) NOT NULL,
  `address` varchar(200) NOT NULL,
  `state` varchar(20) NOT NULL,
  `message` varchar(500) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_us`
--

INSERT INTO `contact_us` (`c_id`, `f_name`, `l_name`, `email`, `phone`, `address`, `state`, `message`, `status`) VALUES
(2, 'sagar', 'Thombare', 'sagarthombare1932@gmail.com', 2147483647, 'ballalwadi', 'Georgia', 'nice', '0'),
(3, 'suyog', 'Gunjal', 'sagarthombare71@gmail.com', 2147483647, 'pune', 'Kansas', 'nice', '0'),
(4, 'mayur', 'shinde', 'sagarthombare71@gmail.com', 1234567892, 'pune', 'Indiana', 'vsgsjsdgsds', '0'),
(5, 'sagar', 'thombare', 'snehadhondkar1972@gmail.com', 1234567898, 'pune', 'Iowa', 'dsdsdaf', '0'),
(6, 'Dhananjay', 'Thite', 'dthite44@gmail.com', 2147483647, 'pune', 'Alaska', 'Verry Good', '0');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
`id` int(10) NOT NULL,
  `f_name` varchar(20) NOT NULL,
  `l_name` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `f_name`, `l_name`, `email`, `message`) VALUES
(1, 'sagar', 'Thombare', 'sagarthombare1932@gm', 'Nice'),
(2, 'sandeep', 'mandlik', 'sandeepmandlik033@gm', 'Nice');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE IF NOT EXISTS `section` (
`id` int(10) NOT NULL,
  `f_name` varchar(20) NOT NULL,
  `l_name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `mobile` int(20) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` varchar(50) NOT NULL,
  `section` varchar(50) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `section`
--

INSERT INTO `section` (`id`, `f_name`, `l_name`, `email`, `password`, `mobile`, `dob`, `gender`, `address`, `section`, `status`) VALUES
(1, 'sagar', 'Thombare', 'sagarthombare1932@gmail.com', 'creation', 2147483647, '1993-03-18', 'male', 'ballalwadi', 'section3', '0');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE IF NOT EXISTS `signup` (
`id` int(10) NOT NULL,
  `f_name` varchar(20) NOT NULL,
  `l_name` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `conform_password` varchar(50) NOT NULL,
  `date` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id`, `f_name`, `l_name`, `email`, `password`, `conform_password`, `date`, `gender`, `status`) VALUES
(3, 'sagar', 'Thombare', 'sagarthombare1932@gmail.com', '8dfd8ac0990c9d9f3e2c7f833121aaef', '8dfd8ac0990c9d9f3e2c7f833121aaef', 'Day/Month/Year', 'male', '0'),
(4, 'Dhananjay', 'Thite', 'dthite44@gmail.com', 'f57059454f0fa0dc3060350c18594adf', 'f57059454f0fa0dc3060350c18594adf', 'Day/Month/Year', 'male', '0'),
(5, 'pranav', 'ghaisas', 'pranavghaisas@gmail.com', 'cad89ffe7838c6264de3b0a07a13c4c7', 'cad89ffe7838c6264de3b0a07a13c4c7', 'Day/Month/Year', 'male', '0'),
(6, 'mayur', 'varpe', 'mayurvarpe@gmail.com', '25d55ad283aa400af464c76d713c07ad', '25d55ad283aa400af464c76d713c07ad', '2015-10-14', 'male', '0'),
(7, 'arun', 'chakve', 'arunchakve@gmail.com', '25d55ad283aa400af464c76d713c07ad', '25d55ad283aa400af464c76d713c07ad', '2015-10-13', 'male', '0');

-- --------------------------------------------------------

--
-- Table structure for table `userform`
--

CREATE TABLE IF NOT EXISTS `userform` (
`id` int(10) NOT NULL,
  `f_name` varchar(20) NOT NULL,
  `m_name` varchar(20) NOT NULL,
  `l_name` varchar(20) NOT NULL,
  `dob` varchar(15) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `request_id` varchar(20) NOT NULL,
  `p_address` varchar(100) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `occuption` varchar(20) NOT NULL,
  `dd_number` int(10) NOT NULL,
  `profile_pic` varchar(50) NOT NULL,
  `document` varchar(50) NOT NULL,
  `user_id` int(10) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userform`
--

INSERT INTO `userform` (`id`, `f_name`, `m_name`, `l_name`, `dob`, `gender`, `email`, `request_id`, `p_address`, `mobile`, `occuption`, `dd_number`, `profile_pic`, `document`, `user_id`, `status`) VALUES
(5, 'sagar', 'Dinkar', 'Thombare', '2015-03-18', 'male', 'sagarthombare1932@gmail.com', '_YSOw#aX265491', 'Ballalwadi', '2147483647', 'student', 323443, '12038467_954819137926953_1412189463917456380_n.jpg', 'IMG_20150921_181738.jpg', 3, '2'),
(6, 'mayur', 'gulab', 'varpe', '2015-10-06', 'male', 'mayurvarpe@gmail.com', 'bejEyJWO910827', 'sssdsdsd', '2323233434', 'wewewewewe', 344545, 'MayurProfileImage3.jpg', 'Sagar1.jpg', 6, '0'),
(7, 'sagar', 'Dinkar', 'Thombare', '2015-10-13', 'male', 'sagarthombare1932@gmail.com', '*ApoUJPO176930', 'pune', '9730952719', 'student', 323232, 'Sagar1.jpg', 'MCS13-2.pdf', 3, '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_us`
--
ALTER TABLE `contact_us`
 ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userform`
--
ALTER TABLE `userform`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `contact_us`
--
ALTER TABLE `contact_us`
MODIFY `c_id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `section`
--
ALTER TABLE `section`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `signup`
--
ALTER TABLE `signup`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `userform`
--
ALTER TABLE `userform`
MODIFY `id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
