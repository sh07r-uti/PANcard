<?php
$ih=100;
$iw=200;
$i=imagecreate($iw,$ih);
$col=imagecolorallocate($i,200,200,200);
$licol=imagecolorallocate($i,0,0,0);
imagearc($i,125,50,50,50,30,150,$licol);
imagearc($i,125,50,70,70,0,360,$licol);
imagearc($i,110,45,20,20,190,-10,$licol);
imagearc($i,140,45,20,20,190,-10,$licol);
imagearc($i,110,40,10,10,-10,190,$licol);
imagearc($i,140,40,10,10,-10,190,$licol);
header('content-type: image/jpeg');
imagejpeg($i);
imagedestroy($i);
?>