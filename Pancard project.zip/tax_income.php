<?php
include "connection.php";

	     $id=$_GET['id'];
         $status=3;		 
	    
              $query1 = mysql_query("UPDATE userform SET status='$status' WHERE id='$id'");
              if($query1)
		{
              
			   echo "<html><body background='img/body-bg.png'><script>alert('Successfully Verify.');</script></body></html>";
			   header("refresh:1; url=income_tax.php");
	    }else
		{
		       
			    echo "<html><body background='img/body-bg.png'><script>alert('Verify Error');</script></body></html>";
			   header("refresh:1; url=income_tax.php");
		}
 
     
			
    mysql_close($con);
?>