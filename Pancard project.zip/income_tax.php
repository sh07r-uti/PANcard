<?php 
session_start();
include "connection.php";

if(!isset($_SESSION['id']))
{
header("location:/civilregistration/adminpanel/loginsection3.html");
}
else{
	   $user_id=$_SESSION['user_id'];
	   $query=mysql_query("select f_name,l_name,email,id from section where id='$user_id'");
	   $f_name=mysql_result($query,0,0);
	   $l_name=mysql_result($query,0,1);
	  $email=mysql_result($query,0,2);
	 
	  
	?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Income Tax</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="css/bootstrap-theme.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	
	<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet'  type='text/css'>
	<style type="text/css">
	
	h2 {
  text-align: center;
}

table caption {
	padding: .5em 0;
}

@media screen and (max-width: 767px) {
  table caption {
    border-bottom: 1px solid #ddd;
  }
}

.p {
  text-align: center;
  padding-top: 140px;
  font-size: 14px;
}
	
	</style>
	
  </head>

  <body role="document">

  
    <div class="container">
 <div class="page-header">
	       <ul class="nav nav-pills pull-right">
            <li><a href="section3.php">Home</a></li>
            <li  class="active"><a href="income_tax.php">Verification</a></li>
			 <li><a href="logoutsection3.php">LogOut</a></li>
          </ul>
	  
	  
        <h3>Income Tax Department</h3>
      </div> 
	  
	  
	
	
	
	 <div class="row">
    <div class="col-xs-12">
      <div class="table-responsive">
        <table summary="This table shows how to create responsive tables using Bootstrap's default functionality" class="table table-bordered table-hover">
          <caption class="text-center">Income Tax Department </caption>
          <thead>
		  
		  
		  
		  
            <tr>
                                               <th>ID</th>
                                  <th>Name</th>
								  
								  <th>Date Of Birth</th>
								  <th>Gender</th>
                                  <th>Email</th>
								  <th>Permant Address</th>
								  <th>Mobile</th>
								  <th>Occupation</th>
								  <th>DD Number</th>	
								  <th>Profile Picture</th>
								  <th>Document</th>
								   <th>Status</th>
								
								  
            </tr>
          </thead>
          <tbody
							  <?php $query=mysql_query("select * from userform where status='2'"); 
							   $i=0;
	                            while($row = mysql_fetch_array($query)){ $i++;  ?>
                              <tr>
                                  <td><?php echo $i; ?></td>
								  <td><?php echo $row['f_name']." ".$row['m_name']." ".$row['l_name']; ?></td>
								 
								  <td><?php echo $row['dob']; ?></td>
								  <td><?php echo $row['gender']; ?></td>
								  <td><?php echo $row['email']; ?></td>
								  <td><?php echo $row['p_address']; ?></td>
								  <td><?php echo $row['mobile']; ?></td>
								  <td><?php echo $row['occuption']; ?></td>
								   <td><?php echo $row['dd_number']; ?></td>
								  <td><?php echo $row['profile_pic']; ?></td>
								  <td><?php echo $row['document']; ?></td>
								   <td>
								      <span>
									 
									  <a href="tax_income.php?id=<?php echo $row['id']; ?>" class="btn btn-success" role="button">Verify</a>
									  </span>
								  </td>
                                  
                                  
                              </tr>
								<?php }?>
                              </tbody>
          <tfoot>
            <tr>
              <td colspan="12" class="text-center">Data retrieved from User Section</td>
            </tr>
          </tfoot>
        </table>
      </div><!--end of .table-responsive-->
    </div>
  </div>
	
	
	
	
	
	  
	  
      <div class="navbar navbar-inverse my-footer">
        <div class="container-fluid">
            <div class="row">
		
               <div class="col-sm-4 col-sm-offset-4 text-center">
                <p class="navbar-text text-center">2015 © pancard. All rights reserved.</p>
			   </div>	
            </div>
			
			
			 <div class="row">
		 <div class="col-sm-7 col-sm-offset-2 text-center">
                      
                          <hr>
						<ul class="list-inline center-block">
						<li><a href="http://facebook.com"><img src="assets/soc_fb.png"></a></li>
						<li><a href="http://twitter.com"><img src="assets/soc_tw.png"></a></li>
						<li><a href="http://google.com"><img src="assets/soc_gplus.png"></a></li>
						<li><a href="http://pinterest.com"><img src="assets/soc_lik.png"></a></li>
						</ul>
  	                </div><!--/col-->
              
			   </div>	
            </div>
			
			
        </div>
	
    </div> <!-- /container    <img src="img/pancard.jpg" class="img-responsive" alt="pancard">    -->

	

	


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/docs.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>

<?php }?>
