<?php

//include "connection.php";
//include "status.php";
$id=0;
$con=mysqli_connect("localhost","root","","pancard") or die("nay hot connection");
        $f_name=$_POST['f_name'];
	$l_name=$_POST['l_name'];
	$email=$_POST['email'];
	$phone=$_POST['mobile'];
	$address=$_POST['address'];
	$state1=$_POST['state'];
	$message=$_POST['message'];
	$status=0;
	 
	 
	
      $insert="insert into contact_us values('$id','$f_name','$l_name','$email','$phone','$address','$state1','$message','$status')";
	  $res=mysqli_query($con,$insert);
	  
      if($res)
     {
		$id++;
		echo "<html><body background='img/body-bg.png'><script>alert('Successfully Insert');</script></body></html>";
	    header("refresh:1; url=contact_us.html");
		exit();
	 }
    else
    {
		echo "<html><body background='img/body-bg.png'><script>alert('Insert Error');</script></body></html>";
		header("refresh:1; url=contact_us.html");

    }
			
  //  pg_close($con);



?>
