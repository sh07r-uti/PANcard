<?php

include "connection.php";

	     $email=$_POST['email']; 
		 $department=$_POST['department'];
		 
		 
		 if($department=="section1")
		 {
		 $section="section1";
	     $query="select email from section where email='$email' and section='$section'";
         $execute=mysql_query($query,$con);
         if(mysql_num_rows($execute)>0)
{
			 $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%&*_";
             $password = substr( str_shuffle( $chars ), 0, 8 );
			
			  
			  //$password1= md5($password);
              $query1 = mysql_query("UPDATE section SET password='$password' WHERE email='$email'");
              if($query1)
		{
              $to = $email;
              $subject = 'Your New Password...';
              $message = 'Hello User Your new password : '.$password.'E-mail: '.$email.'Now you can login with this email and password.';
			  
              if(mail($to, $subject, $message ))
            {
              
			   echo "<html><body background='img/body-bg.png'><script>alert('Password Change Successfully.');</script></body></html>";
			   header("refresh:2; url=/civilregistration/adminpanel/login.html");
			  
            }
			   
	    }
}	 

		 }
      
	
	
	 if($department=="section2")
	  {
		  
				 $section="section2";
	     $query="select email from section where email='$email' and section='$section'";
         $execute=mysql_query($query,$con);
         if(mysql_num_rows($execute)>0)
{
			 $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%&*_";
             $password = substr( str_shuffle( $chars ), 0, 8 );
			
			  
			  //$password1= md5($password);
              $query1 = mysql_query("UPDATE section SET password='$password' WHERE email='$email'");
              if($query1)
		{
              $to = $email;
              $subject = 'Your New Password...';
              $message = 'Hello User Your new password : '.$password.'E-mail: '.$email.'Now you can login with this email and password.';
			  
              if(mail($to, $subject, $message ))
            {
              
			   echo "<html><body background='img/body-bg.png'><script>alert('Password Change Successfully.');</script></body></html>";
			   header("refresh:2; url=/civilregistration/adminpanel/login.html");
			  
            }
			   
	    }
}
			
		
	  }
	
	
	
	
	
	 if($department=="section3")
	  {
		   
		    $section="section3";
	     $query="select email from section where email='$email' and section='$section'";
         $execute=mysql_query($query,$con);
         if(mysql_num_rows($execute)>0)
{
			 $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%&*_";
             $password = substr( str_shuffle( $chars ), 0, 8 );
			
			  
			  //$password1= md5($password);
              $query1 = mysql_query("UPDATE section SET password='$password' WHERE email='$email'");
              if($query1)
		{
              $to = $email;
              $subject = 'Your New Password...';
              $message = 'Hello User Your new password : '.$password.'E-mail: '.$email.'Now you can login with this email and password.';
			  
              if(mail($to, $subject, $message ))
            {
              
			   echo "<html><body background='img/body-bg.png'><script>alert('Password Change Successfully.');</script></body></html>";
			   header("refresh:2; url=/civilregistration/adminpanel/login.html");
			  
            }
			   
	    }
}	
		   
	  }
	    else
    {
       
		echo "<html><body background='img/body-bg.png'><script>alert('Invalid E-mail Address.');</script></body></html>";
        header("refresh:2; url=/civilregistration/adminpanel/login.html");
    }
	
			
    mysql_close($con);
?>